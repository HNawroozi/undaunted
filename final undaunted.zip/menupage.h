#pragma once
#include <QWidget>

class QPushButton;

class MenuPage : public QWidget {
    Q_OBJECT
public:
    explicit MenuPage(QWidget *parent = nullptr);
signals:
    void startGameRequested();
    void exitRequested();
private:
    QPushButton *startBtn;
    QPushButton *editorBtn;
    QPushButton *exitBtn;
};
