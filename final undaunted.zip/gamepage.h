#ifndef GAMEPAGE_H
#define GAMEPAGE_H

#include <QWidget>

class QGridLayout;

class GamePage : public QWidget
{
    Q_OBJECT

public:
    explicit GamePage(QWidget *parent = nullptr);
    void loadBoard(const QString &filename);

signals:
    void backToMenu();

private:
    QString getCellStyle(const QString &content);
    QGridLayout *boardGrid;
};

#endif
