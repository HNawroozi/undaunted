#ifndef LOGINPAGE_H
#define LOGINPAGE_H

#include <QWidget>

class QLineEdit;
class QPushButton;

class LoginPage : public QWidget
{
    Q_OBJECT

public:
    explicit LoginPage(QWidget *parent = nullptr);

signals:
    void loginSuccessful(const QString &player1, const QString &player2);

private slots:
    void attemptLogin();

private:
    QLineEdit   *player1Edit = nullptr;
    QLineEdit   *player2Edit = nullptr;
    QPushButton *loginBtn    = nullptr;
};

#endif
