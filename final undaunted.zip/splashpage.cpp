
#include "splashpage.h"
#include <QLabel>
#include <QVBoxLayout>
#include <QTimer>
#include <QFont>

SplashPage::SplashPage(QWidget *parent) : QWidget(parent) {

    setStyleSheet("background-image: url(:/images/splash_new.jpg);"
                  "background-position: center;"
                  "background-repeat: no-repeat;");

    auto *layout = new QVBoxLayout(this);
    layout->setContentsMargins(60, 120, 60, 120);
    layout->setSpacing(30);


    QLabel *title = new QLabel(
        "<div style='font-size: 100px; font-family: Impact; font-weight: bold; "
        "color: #ff4500; letter-spacing: 10px; "
        "text-shadow: 0 0 20px #ff0000, 0 0 40px #ff6600, 5px 5px 0 #000;'>"
        "UNDAUNTED"
        "</div>", this);
    title->setAlignment(Qt::AlignCenter);


    QLabel *subtitle = new QLabel(
        "<div style='font-size: 38px; color: #ffd700; font-style: italic; "
        "text-shadow: 0 0 15px #ff9900, 3px 3px 10px black;'>"
        "NORMANDY • 1944"
        "</div>", this);
    subtitle->setAlignment(Qt::AlignCenter);


    QLabel *credit = new QLabel(
        "<div style='color: #cccccc; font-size: 18px; margin-top: 100px;'>"
        "Developed by Hamed Nawroozi and Yousef Ghasemzadah • Ferdowsi University"
        "</div>", this);
    credit->setAlignment(Qt::AlignCenter);

    layout->addStretch();
    layout->addWidget(title);
    layout->addWidget(subtitle);
    layout->addStretch();
    layout->addWidget(credit);
    layout->addStretch();


    QTimer::singleShot(3000, this, [this](){ emit finished(); });
}
