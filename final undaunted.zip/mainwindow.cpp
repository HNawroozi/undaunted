#include "mainwindow.h"
#include "splashpage.h"
#include "loginpage.h"
#include "menupage.h"
#include "gamepage.h"

#include <QApplication>
#include <QTimer>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{

    stackedWidget = new QStackedWidget(this);
    setCentralWidget(stackedWidget);
    resize(1200, 800);


    splashPage = new SplashPage(this);
    loginPage  = new LoginPage(this);
    menuPage   = new MenuPage(this);
    gamePage   = new GamePage(this);


    stackedWidget->addWidget(splashPage);
    stackedWidget->addWidget(loginPage);
    stackedWidget->addWidget(menuPage);
    stackedWidget->addWidget(gamePage);


    stackedWidget->setCurrentWidget(splashPage);
    qDebug() << "Splash page shown";


    QTimer::singleShot(3000, this, [this]() {
        qDebug() << "Going to Login page";
        stackedWidget->setCurrentWidget(loginPage);
    });


    connect(loginPage, &LoginPage::loginSuccessful, this, &MainWindow::showMenu);
    connect(menuPage,  &MenuPage::startGameRequested, this, &MainWindow::startGame);
    connect(gamePage,  &GamePage::backToMenu, this, &MainWindow::showMenuFromGame);
    connect(menuPage,  &MenuPage::exitRequested, qApp, &QApplication::quit);

    qDebug() << "MainWindow initialized successfully!";
}

void MainWindow::showMenu(const QString &, const QString &)
{
    qDebug() << "Going to Menu page";
    stackedWidget->setCurrentWidget(menuPage);
}

void MainWindow::showMenuFromGame()
{
    qDebug() << "Back to Menu from Game";
    stackedWidget->setCurrentWidget(menuPage);
}

void MainWindow::startGame()
{
    qDebug() << "Starting game...";

    gamePage->loadBoard(":/boards/sample_board.txt");
    stackedWidget->setCurrentWidget(gamePage);
}
MainWindow::~MainWindow()
{

    delete stackedWidget;
    delete splashPage;
    delete loginPage;
    delete menuPage;
    delete gamePage;
}
