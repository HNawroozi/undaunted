#pragma once
#include <QPixmap>
#include <QString>

struct Tile {
    int id = 0;
    QPixmap pix;
    Tile() {}
    Tile(int _id, const QString &path) : id(_id), pix(path) {}
};
