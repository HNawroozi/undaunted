#include "board.h"
#include <QFile>
#include <QTextStream>
#include <QPainter>
#include <QDebug>

Board::Board(QWidget *parent) : QWidget(parent) {
    setMinimumSize(800, 600);
    mapLoaded = false;
}

static Tile tileForNumber(int n) {
    switch (n) {
    case 0: return Tile(0, QStringLiteral(":/img/tile_empty.jpg"));
    case 1: return Tile(1, QStringLiteral(":/img/tile_wall.png"));
    case 2: return Tile(2, QStringLiteral(":/img/tile_spawn.png"));
    default: return Tile(-1, QStringLiteral(":/img/tile_empty.jpg"));
    }
}

bool Board::loadFromFile(const QString &resourcePath) {
    QFile f(resourcePath);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qWarning() << "Cannot open board file:" << resourcePath;
        return false;
    }

    QTextStream in(&f);
    grid.clear();
    rows = cols = 0;

    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty()) continue;

        QVector<Cell> row;
        QStringList parts = line.split('|', Qt::SkipEmptyParts);

        for (QString token : parts) {
            token = token.trimmed();
            if (token.isEmpty()) continue;

            QStringList pieces = token.split(':');
            if (pieces.size() != 2) continue;

            Cell c;
            c.code = pieces[0].trimmed();
            bool ok;
            c.number = pieces[1].trimmed().toInt(&ok);
            c.tile = tileForNumber(ok ? c.number : -1);
            row.append(c);
        }

        if (!row.isEmpty()) {
            grid.append(row);
            cols = qMax(cols, (int)row.size());
        }
    }

    rows = grid.size();
    if (rows > 0 && cols > 0) {
        mapLoaded = true;
        update();
        return true;
    }
    return false;
}

void Board::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    if (grid.isEmpty() || rows == 0 || cols == 0) {
        p.setPen(Qt::white);
        p.setFont(QFont("Arial", 20));
        p.drawText(rect(), Qt::AlignCenter, "No board loaded");
        return;
    }

    int cellWidth = width() / cols;
    int cellHeight = height() / rows;

    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < (int)grid[i].size() && j < cols; ++j) {
            QRect cellRect(j * cellWidth, i * cellHeight, cellWidth, cellHeight);
            const Cell &cell = grid[i][j];

            if (!cell.tile.pix.isNull()) {
                p.drawPixmap(cellRect, cell.tile.pix.scaled(cellRect.size(), Qt::KeepAspectRatioByExpanding, Qt::SmoothTransformation));
            } else {
                p.fillRect(cellRect, QColor(50, 50, 50));
            }

            p.setPen(QPen(Qt::black, 2));
            p.drawRect(cellRect);

            p.setPen(Qt::white);
            p.setFont(QFont("Tahoma", 10, QFont::Bold));
            p.drawText(cellRect.adjusted(5, 5, -5, -5), Qt::AlignTop | Qt::AlignLeft, cell.code + ":" + QString::number(cell.number));
        }
    }
}
