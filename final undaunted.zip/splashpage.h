#pragma once
#include <QWidget>

class QLabel;

class SplashPage : public QWidget {
    Q_OBJECT
public:
    explicit SplashPage(QWidget *parent = nullptr);
signals:
    void finished();
};
