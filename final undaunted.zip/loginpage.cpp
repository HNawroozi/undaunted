#include "loginpage.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QMessageBox>
#include <QRegularExpressionValidator>
#include <QDebug>

LoginPage::LoginPage(QWidget *parent) : QWidget(parent)
{
    setStyleSheet("background-image: url(:/images/login_background.jpg);"
                  "background-position: center; background-repeat: no-repeat;");

    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(100, 100, 100, 100);

    QLabel *title = new QLabel("<h1 style='color: gold; text-shadow: 4px 4px 12px black;'>UNDAUNTED: NORMANDY</h1>", this);
    title->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(title);

    QLabel *subtitle = new QLabel("<h2>Players Login</h2>", this);
    subtitle->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(subtitle);

    mainLayout->addStretch();

    auto *playersLayout = new QHBoxLayout();
    playersLayout->setSpacing(50);

    player1Edit = new QLineEdit(this);
    player1Edit->setPlaceholderText("Player 1");
    player1Edit->setMaxLength(8);
    player1Edit->setValidator(new QRegularExpressionValidator(QRegularExpression("[A-Za-z]{1,8}"), this));
    player1Edit->setFixedWidth(300);

    player2Edit = new QLineEdit(this);
    player2Edit->setPlaceholderText("Player 2");
    player2Edit->setMaxLength(8);
    player2Edit->setValidator(new QRegularExpressionValidator(QRegularExpression("[A-Za-z]{1,8}"), this));
    player2Edit->setFixedWidth(300);

    playersLayout->addWidget(new QLabel("Player 1:", this));
    playersLayout->addWidget(player1Edit);
    playersLayout->addWidget(new QLabel("Player 2:", this));
    playersLayout->addWidget(player2Edit);

    mainLayout->addLayout(playersLayout);
    mainLayout->addStretch();

    loginBtn = new QPushButton("ENTER BATTLEFIELD", this);
    loginBtn->setFixedHeight(80);
    loginBtn->setStyleSheet("font-size: 24px; background: #556b2f; color: gold; border: 4px solid gold;");
    mainLayout->addWidget(loginBtn, 0, Qt::AlignCenter);


    connect(loginBtn, &QPushButton::clicked, this, &LoginPage::attemptLogin);
}

void LoginPage::attemptLogin()
{
    QString p1 = player1Edit->text().trimmed();
    QString p2 = player2Edit->text().trimmed();

    qDebug() << "Login attempted:" << p1 << p2;

    if (p1.isEmpty() || p2.isEmpty()) {
        QMessageBox::warning(this, "خطا", "نام بازیکن را وارد کنید!");
        return;
    }

    if (p1 == p2) {
        QMessageBox::warning(this, "خطا", "نام دو بازیکن یکسان است!");
        return;
    }


    qDebug() << "Login successful! Emitting signal...";
    emit loginSuccessful(p1, p2);
}
