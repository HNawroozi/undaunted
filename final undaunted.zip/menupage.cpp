#include "menupage.h"
#include <QVBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QFont>

MenuPage::MenuPage(QWidget *parent) : QWidget(parent) {

    setStyleSheet("background-image: url(:/images/menu_background.jpg);"
                  "background-position: center; background-repeat: no-repeat;");

    auto *layout = new QVBoxLayout(this);
    layout->setSpacing(25);


    QLabel *title = new QLabel(
        "<h1 style='color:#ffcc00; font-family: Georgia; font-size: 72px; "
        "text-shadow: 0 0 30px #ff9900, 0 0 60px #ff6600;'>UNDAUNTED</h1>", this);
    title->setAlignment(Qt::AlignCenter);
    layout->addWidget(title);

    QLabel *tagline = new QLabel(
        "<h3 style='color:#ff9966; font-style:italic;'>Fight for Victory</h3>", this);
    tagline->setAlignment(Qt::AlignCenter);
    layout->addWidget(tagline);

    layout->addStretch();

    auto createButton = [this](const QString &text) -> QPushButton* {
        QPushButton *btn = new QPushButton(text, this);
        btn->setFixedSize(380, 80);
        btn->setStyleSheet(
            "QPushButton { background: qlineargradient(x1:0, y1:0, x2:0, y2:1, "
            "stop:0 #334455, stop:1 #112233); color: #ffcc00; font-size: 24px; "
            "font-weight: bold; border: 3px solid #ff9900; border-radius: 15px; }"
            "QPushButton:hover { background: qlineargradient(x1:0, y1:0, x2:0, y2:1, "
            "stop:0 #556677, stop:1 #223344); }"
            "QPushButton:pressed { background: #112233; }"
            );
        return btn;
    };

    startBtn = createButton("START CAMPAIGN");
    editorBtn = createButton("BOARD EDITOR");
    exitBtn = createButton("EXIT GAME");

    layout->addWidget(startBtn, 0, Qt::AlignCenter);
    layout->addWidget(editorBtn, 0, Qt::AlignCenter);
    layout->addWidget(exitBtn, 0, Qt::AlignCenter);

    layout->addStretch();

    connect(startBtn, &QPushButton::clicked, this, &MenuPage::startGameRequested);
    connect(exitBtn, &QPushButton::clicked, this, &MenuPage::exitRequested);
}
