#include "gamepage.h"
#include <QFile>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QResource>
#include <QTextStream>
#include <QGridLayout>
#include <QFrame>
#include <QDebug>

GamePage::GamePage(QWidget *parent) : QWidget(parent)
{
    setStyleSheet("background-color: #0f0f0f;");

    auto *mainLayout = new QVBoxLayout(this);

    QLabel *title = new QLabel("<h1 style='color: gold; text-shadow: 4px 4px 12px black;'>UNDAUNTED: NORMANDY</h1>", this);
    title->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(title);

    boardGrid = new QGridLayout();
    boardGrid->setSpacing(4);

    QFrame *boardFrame = new QFrame(this);
    boardFrame->setStyleSheet("background: #222; border: 6px solid gold; border-radius: 15px; padding: 20px;");
    boardFrame->setLayout(boardGrid);
    mainLayout->addWidget(boardFrame, 0, Qt::AlignCenter);

    QPushButton *backBtn = new QPushButton("Back to menu", this);
    backBtn->setFixedSize(320, 90);
    backBtn->setStyleSheet("font-size: 28px; background: #8B0000; color: gold; border: 4px solid gold; font-weight: bold;");
    mainLayout->addWidget(backBtn, 0, Qt::AlignCenter);

    connect(backBtn, &QPushButton::clicked, this, &GamePage::backToMenu);
}

void GamePage::loadBoard(const QString &resourcePath)
{

    QLayoutItem *item;
    while ((item = boardGrid->takeAt(0))) {
        delete item->widget();
        delete item;
    }

    QFile file(resourcePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QLabel *err = new QLabel("warning the map is not found!\n" + resourcePath, this);
        err->setStyleSheet("color: red; font-size: 32px; background: black; padding: 20px;");
        err->setAlignment(Qt::AlignCenter);
        boardGrid->addWidget(err, 0, 0, 1, 10);
        return;
    }

    QTextStream in(&file);
    int row = 0;

    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();


        if (line.startsWith("SP:")) continue;
        if (line.isEmpty()) continue;

        QStringList cells = line.split('|', Qt::SkipEmptyParts);
        for (int col = 0; col < cells.size(); ++col) {
            QString raw = cells[col].trimmed();
            QString code = raw.section(':', 0, 0);
            int units = raw.section(':', 1).toInt();

            QLabel *cell = new QLabel(this);
            cell->setFixedSize(90, 90);
            cell->setAlignment(Qt::AlignCenter);

            if (units == 0) {
                cell->setText(code);
                cell->setStyleSheet("background: #1a3d1a; color: #88cc88; font-weight: bold; font-size: 24px; border: 3px solid #556B2F;");
            }
            else if (units == 1) {
                cell->setText(code + "\n");
                cell->setStyleSheet("background: #8B4513; color: gold; font-weight: bold; font-size: 20px; border: 5px solid gold;");
            }
            else if (units >= 2) {
                cell->setText(code + "\n");
                cell->setStyleSheet("background: #B22222; color: white; font-weight: bold; font-size: 18px; border: 6px solid gold;");
            }

            boardGrid->addWidget(cell, row, col);
        }
        row++;
    }

    file.close();
    qDebug() << "map loaded sueccessfully from" << resourcePath << "loaded!";
}
