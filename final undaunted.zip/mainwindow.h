#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>

class SplashPage;
class LoginPage;
class MenuPage;
class GamePage;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void showMenu(const QString &player1 = "", const QString &player2 = "");
    void showMenuFromGame();
    void startGame();

private:
    QStackedWidget *stackedWidget = nullptr;

    SplashPage *splashPage = nullptr;
    LoginPage  *loginPage  = nullptr;
    MenuPage   *menuPage   = nullptr;
    GamePage   *gamePage   = nullptr;
};

#endif
