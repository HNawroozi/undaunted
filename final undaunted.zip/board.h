
#pragma once
#include <QWidget>
#include <QVector>
#include <QString>
#include "tile.h"

struct Cell {
    QString code;
    int number;
    Tile tile;
};

class Board : public QWidget {
    Q_OBJECT
public:
    explicit Board(QWidget *parent = nullptr);
    bool loadFromFile(const QString &resourcePath);
protected:
    void paintEvent(QPaintEvent *event) override;
private:
    QVector<QVector<Cell>> grid;
    int rows{0}, cols{0};
    bool mapLoaded{false};
};
